------------- POWER CHASE - Created by Marc Latorre -------------

ABOUT
Open the file "PowerChase.exe" to start the game.
The game consists in 3 different levels. Each level has his final boss that you must defeat before passing to the following level.
In order to enter the boss room there is a key hidden in each level that you will have to find.
The objective of the game is to defeat the 3 bosses in the game.

CONTROLS
A - Move left
D - Move right
SPACE - Jump (can jump twice)
Mouse left click - Swing sword attack
Mouse right click - Dagger throw skill (in the mouse direction)
Shift - Dash skill (move fast in the mouse direction)
W - Dark shadows skill (deals area damage to all enemies around, the closest the enemies are, the more damage it deals)
1 - Sharp sword: Increase attack buff
2 - Extra armor: Increase defense buff
3 - Deflection: Returns part of the damage you receive.
4 - Blood sword: Heal part of the damage from your attacks
S - Use health potion to restore your health

---------------------- THANKS FOR PLAYING -----------------------